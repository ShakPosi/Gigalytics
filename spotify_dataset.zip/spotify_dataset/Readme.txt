i. top_200_weekly.csv contains the spotify weekly top 200 tracks starting from March 2019 to Feb 2020. The file combiness records from the United Kingdom region and worldwide weekly charts.

ii. Spotify_Track_Details.csv provides more details regarding the tracks in i above. Details such as track url, artist spotify id and artist music brainz id can be found here.